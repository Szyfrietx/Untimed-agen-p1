// Untimed v1.0.0 | 2026-10-06 | P-UNTIMED-ANDROID-001
package com.untimed.app.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Settings
import com.untimed.core.data.ServiceLauncher
import com.untimed.core.data.SettingsRepository
import com.untimed.core.engine.BankMode
import com.untimed.core.engine.DecayWorker
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * After a reboot: re-register the midnight decay, resume a rest countdown that was running (the engine
 * drains it against wall-clock time on restore), and bring the floating bubble back if it was enabled.
 */
@AndroidEntryPoint
class BootReceiver : BroadcastReceiver() {
    @Inject lateinit var settings: SettingsRepository

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent) // Hilt injects here
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        DecayWorker.schedule(context)
        val pending = goAsync()
        CoroutineScope(Dispatchers.Default).launch {
            try {
                if (settings.snapshot.first().mode == BankMode.RESTING.name) ServiceLauncher.startTimer(context)
                if (settings.settings.first().overlayEnabled && Settings.canDrawOverlays(context)) {
                    ServiceLauncher.setOverlay(context, true)
                }
            } finally {
                pending.finish()
            }
        }
    }
}
