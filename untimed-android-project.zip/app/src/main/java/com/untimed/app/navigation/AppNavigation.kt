// Untimed v1.0.0 | 2026-10-06 | P-UNTIMED-ANDROID-001
package com.untimed.app.navigation

import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.untimed.feature.bank.TimeBankScreen
import com.untimed.feature.blocks.BlockListScreen
import com.untimed.feature.settings.SettingsScreen
import com.untimed.feature.stats.StatsScreen

private enum class Route(val path: String, val label: String) {
    Bank("bank", "Bank"),
    Blocks("blocks", "Blocks"),
    Stats("stats", "Stats"),
    Settings("settings", "Settings"),
}

@Composable
fun AppNavigation() {
    val nav = rememberNavController()
    val current = nav.currentBackStackEntryAsState().value?.destination?.route
    Scaffold(
        // Screens own their top app bars and status-bar insets; only the bottom bar is handled here.
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        bottomBar = {
            NavigationBar {
                Route.entries.forEach { route ->
                    NavigationBarItem(
                        selected = current == route.path,
                        onClick = {
                            nav.navigate(route.path) {
                                popUpTo(nav.graph.findStartDestination().id) { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        icon = {},
                        label = { Text(route.label) },
                        alwaysShowLabel = true,
                    )
                }
            }
        },
    ) { inner ->
        NavHost(nav, startDestination = Route.Bank.path, modifier = Modifier.padding(inner)) {
            composable(Route.Bank.path) { TimeBankScreen() }
            composable(Route.Blocks.path) { BlockListScreen() }
            composable(Route.Stats.path) { StatsScreen() }
            composable(Route.Settings.path) { SettingsScreen() }
        }
    }
}
