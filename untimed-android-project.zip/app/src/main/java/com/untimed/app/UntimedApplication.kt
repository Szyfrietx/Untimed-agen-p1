// Untimed v1.0.0 | 2026-10-06 | P-UNTIMED-ANDROID-001
package com.untimed.app

import android.app.Application
import com.untimed.core.engine.DecayWorker
import com.untimed.core.service.NotificationBuilder
import dagger.hilt.android.HiltAndroidApp
import javax.inject.Inject

@HiltAndroidApp
class UntimedApplication : Application() {
    @Inject lateinit var notifications: NotificationBuilder

    override fun onCreate() {
        super.onCreate()
        notifications.createChannels()
        DecayWorker.schedule(this)
    }
}
