// Untimed v1.0.0 | 2026-10-06 | P-UNTIMED-ANDROID-001
package com.untimed.app.di

import android.content.Context
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.untimed.core.data.BlockDao
import com.untimed.core.data.BucketTagDao
import com.untimed.core.data.RatioPresetDao
import com.untimed.core.data.SessionDao
import com.untimed.core.data.StreakDao
import com.untimed.core.data.UntimedDatabase
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

/** Database and DAOs. Repositories and engines construct through @Inject. */
@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    /** Default presets and buckets, inserted once when the database file is created. */
    private val seed = object : RoomDatabase.Callback() {
        override fun onCreate(db: SupportSQLiteDatabase) {
            db.execSQL("INSERT INTO ratio_presets (label, workRatio, restRatio, isDefault) VALUES ('5:1 Reverse Pomodoro', 5, 1, 1)")
            db.execSQL("INSERT INTO ratio_presets (label, workRatio, restRatio, isDefault) VALUES ('3:1', 3, 1, 0)")
            db.execSQL("INSERT INTO ratio_presets (label, workRatio, restRatio, isDefault) VALUES ('10:1', 10, 1, 0)")
            db.execSQL("INSERT INTO bucket_tags (name, weight, colorHex) VALUES ('General', 1.0, '#FF6750A4')")
            db.execSQL("INSERT INTO bucket_tags (name, weight, colorHex) VALUES ('Deep work', 1.5, '#FF006874')")
            db.execSQL("INSERT INTO bucket_tags (name, weight, colorHex) VALUES ('Admin', 0.5, '#FF8C4A60')")
        }
    }

    @Provides @Singleton
    fun database(@ApplicationContext context: Context): UntimedDatabase =
        Room.databaseBuilder(context, UntimedDatabase::class.java, "untimed.db")
            .addCallback(seed)
            .fallbackToDestructiveMigration() // D-08: v1 only
            .build()

    @Provides fun sessionDao(db: UntimedDatabase): SessionDao = db.sessionDao()
    @Provides fun blockDao(db: UntimedDatabase): BlockDao = db.blockDao()
    @Provides fun bucketTagDao(db: UntimedDatabase): BucketTagDao = db.bucketTagDao()
    @Provides fun ratioPresetDao(db: UntimedDatabase): RatioPresetDao = db.ratioPresetDao()
    @Provides fun streakDao(db: UntimedDatabase): StreakDao = db.streakDao()
}
