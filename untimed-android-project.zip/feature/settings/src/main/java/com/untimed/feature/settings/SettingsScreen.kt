// Untimed v1.0.0 | 2026-10-06 | P-UNTIMED-ANDROID-001
package com.untimed.feature.settings

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.untimed.core.model.BucketTag
import com.untimed.core.model.RatioPreset
import com.untimed.core.ui.components.ColorWheelPicker
import com.untimed.core.ui.components.PaletteSuggestionEngine
import com.untimed.core.ui.theme.DefaultPalette
import com.untimed.core.ui.theme.toColorOrDefault
import com.untimed.core.ui.theme.toHex

@Composable
fun SettingsScreen(viewModel: SettingsViewModel = hiltViewModel()) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val tags by viewModel.tags.collectAsStateWithLifecycle()
    val presets by viewModel.presets.collectAsStateWithLifecycle()
    SettingsContent(state, tags, presets, viewModel::onEvent)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SettingsContent(
    state: SettingsUiState,
    tags: List<BucketTag>,
    presets: List<RatioPreset>,
    onEvent: (SettingsEvent) -> Unit,
) {
    val context = LocalContext.current
    var addingBucket by remember { mutableStateOf(false) }
    var addingRatio by remember { mutableStateOf(false) }
    Scaffold(topBar = { TopAppBar(title = { Text("Settings") }) }) { padding ->
        LazyColumn(
            modifier = Modifier.padding(padding),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp),
        ) {
            item {
                SettingsSection("Palette") {
                    PaletteEditor(
                        palette = state.palette.ifEmpty { DefaultPalette },
                        onChange = { onEvent(SettingsEvent.SetPalette(it)) },
                    )
                }
            }
            item {
                SettingsSection("Midnight decay") {
                    var draft by remember(state.decayPercent) { mutableFloatStateOf(state.decayPercent.toFloat()) }
                    Text("${draft.toInt()}% of the bank is removed each midnight")
                    Slider(
                        value = draft,
                        onValueChange = { draft = it },
                        onValueChangeFinished = { onEvent(SettingsEvent.SetDecay(draft.toInt())) },
                        valueRange = 10f..90f,
                        steps = 15, // 5% increments
                    )
                }
            }
            item {
                SettingsSection("Buckets") {
                    tags.forEach { Text("${it.name}  x${"%.1f".format(it.weight)}") }
                    TextButton(onClick = { addingBucket = true }) { Text("Add bucket") }
                }
            }
            item {
                SettingsSection("Ratios") {
                    Text(presets.joinToString("   ") { it.label })
                    TextButton(onClick = { addingRatio = true }) { Text("Add ratio") }
                }
            }
            item {
                SettingsSection("Behavior") {
                    ToggleRow("Floating bubble", state.overlayEnabled) { wanted ->
                        if (wanted && !Settings.canDrawOverlays(context)) {
                            context.startActivity(
                                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${context.packageName}"))
                                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                            )
                        } else {
                            onEvent(SettingsEvent.ToggleOverlay(wanted))
                        }
                    }
                    ToggleRow("Keep screen on", state.wakeLockEnabled) { onEvent(SettingsEvent.ToggleWakeLock(it)) }
                    ToggleRow("Sound", state.soundEnabled) { onEvent(SettingsEvent.ToggleSound(it)) }
                    ToggleRow("Haptics", state.hapticEnabled) { onEvent(SettingsEvent.ToggleHaptic(it)) }
                }
            }
        }
    }
    if (addingBucket) {
        AddBucketDialog(onDismiss = { addingBucket = false }) { name, weight ->
            onEvent(SettingsEvent.AddBucket(name, weight))
            addingBucket = false
        }
    }
    if (addingRatio) {
        AddRatioDialog(onDismiss = { addingRatio = false }) { ratio ->
            onEvent(SettingsEvent.AddPreset(ratio))
            addingRatio = false
        }
    }
}

@Composable
private fun AddBucketDialog(onDismiss: () -> Unit, onAdd: (String, Float) -> Unit) {
    var name by remember { mutableStateOf("") }
    var weight by remember { mutableFloatStateOf(1.0f) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("New bucket") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("Name") }, singleLine = true)
                Text("Earning weight x${"%.1f".format(weight)}")
                Slider(weight, { weight = it }, valueRange = 0.5f..2.0f, steps = 14) // 0.1 steps
            }
        },
        confirmButton = { TextButton(enabled = name.isNotBlank(), onClick = { onAdd(name, weight) }) { Text("Add") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

@Composable
private fun AddRatioDialog(onDismiss: () -> Unit, onAdd: (Int) -> Unit) {
    var ratio by remember { mutableFloatStateOf(5f) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("New ratio") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("${ratio.toInt()} minutes of work earn 1 minute of rest")
                Slider(ratio, { ratio = it }, valueRange = 1f..10f, steps = 8)
            }
        },
        confirmButton = { TextButton(onClick = { onAdd(ratio.toInt()) }) { Text("Add") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

@Composable
private fun SettingsSection(title: String, content: @Composable () -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(title, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
        content()
    }
}

@Composable
private fun ToggleRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(label)
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

private val slotNames = listOf("Primary", "Secondary", "Tertiary")

/** Pick a slot, spin the wheel, or adopt a generated scheme built from the primary color. */
@Composable
fun PaletteEditor(palette: List<String>, onChange: (List<String>) -> Unit) {
    var slot by remember { mutableIntStateOf(0) }
    val fallback = Color(0xFF6750A4)
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            slotNames.forEachIndexed { i, name ->
                FilterChip(selected = slot == i, onClick = { slot = i }, label = { Text(name) })
            }
        }
        key(slot) {
            ColorWheelPicker(
                initialColor = palette.getOrNull(slot).toColorOrDefault(fallback),
                onColorChanged = { picked ->
                    onChange(palette.toMutableList().also { list ->
                        while (list.size < 3) list.add(DefaultPalette[list.size])
                        list[slot] = picked.toHex()
                    })
                },
            )
        }
        PalettePreview(palette)
        Text("Suggestions from the primary color", style = MaterialTheme.typography.labelMedium)
        PaletteSuggestionEngine.suggest(palette.getOrNull(0).toColorOrDefault(fallback)).forEach { suggestion ->
            Row(
                Modifier.fillMaxWidth().clickable { onChange(suggestion.colors.map { it.toHex() }) },
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                suggestion.colors.forEach { Swatch(it) }
                Text(suggestion.name)
            }
        }
        TextButton(onClick = { onChange(DefaultPalette) }) { Text("Reset to dynamic color") }
    }
}

@Composable
private fun PalettePreview(palette: List<String>) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        palette.forEach { Swatch(it.toColorOrDefault(Color.Gray)) }
    }
}

@Composable
private fun Swatch(color: Color) {
    Box(Modifier.size(32.dp).clip(CircleShape).background(color))
}
