// Untimed v1.0.0 | 2026-10-06 | P-UNTIMED-ANDROID-001
package com.untimed.feature.blocks

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.untimed.core.data.ServiceLauncher
import com.untimed.core.data.SessionRepository
import com.untimed.core.engine.ElasticRescheduler
import com.untimed.core.engine.SequentialBlockEngine
import com.untimed.core.model.TimeBlock
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.filterNotNull
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

data class BlockListUiState(
    val blocks: List<TimeBlock> = emptyList(),
    val activeBlockId: Long? = null,
    val isSequentialMode: Boolean = false,
    val activeRemainingMs: Long = 0,
    val error: String? = null,
)

sealed interface BlockListEvent {
    data class AddBlock(val title: String, val minutes: Int, val autoAdvance: Boolean) : BlockListEvent
    data class EditBlock(val block: TimeBlock, val title: String, val minutes: Int, val autoAdvance: Boolean) : BlockListEvent
    data class DeleteBlock(val block: TimeBlock) : BlockListEvent
    data object StartChain : BlockListEvent
    data object StopChain : BlockListEvent
    data class ReorderBlock(val block: TimeBlock, val delta: Int) : BlockListEvent
    /** Added beyond Table E to carry the early-completion rule (Q7=A); see G-B05. */
    data object CompleteBlock : BlockListEvent
    data object DismissError : BlockListEvent
}

@OptIn(ExperimentalCoroutinesApi::class)
@HiltViewModel
class BlockListViewModel @Inject constructor(
    @ApplicationContext private val context: Context,
    private val sessions: SessionRepository,
    private val engine: SequentialBlockEngine,
    private val rescheduler: ElasticRescheduler,
) : ViewModel() {

    private val sessionId = MutableStateFlow<Long?>(null)
    private val error = MutableStateFlow<String?>(null)

    init {
        viewModelScope.launch { sessionId.value = sessions.chainSessionId() }
    }

    val uiState: StateFlow<BlockListUiState> = combine(
        sessionId.filterNotNull().flatMapLatest { sessions.observeBlocks(it) },
        engine.state,
        error,
    ) { blocks, chain, err ->
        BlockListUiState(blocks, chain.activeBlockId, chain.running, chain.remainingMs, err)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), BlockListUiState())

    fun onEvent(event: BlockListEvent) {
        viewModelScope.launch {
            val sid = sessionId.value ?: return@launch
            when (event) {
                is BlockListEvent.AddBlock -> {
                    val ok = sessions.addBlock(sid, event.title.ifBlank { "Block" }, minutesToMs(event.minutes), event.autoAdvance)
                    if (!ok) error.value = "A chain holds at most ${SessionRepository.MAX_BLOCKS} blocks."
                }
                is BlockListEvent.EditBlock -> {
                    val list = sessions.blocksNow(sid).toMutableList()
                    val i = list.indexOfFirst { it.id == event.block.id }
                    if (i >= 0) {
                        val old = list[i]
                        list[i] = old.copy(
                            title = event.title.ifBlank { old.title },
                            scheduledEnd = old.scheduledStart + minutesToMs(event.minutes),
                            autoAdvance = event.autoAdvance,
                        )
                        sessions.saveBlocks(rescheduler.cascade(list, i + 1, list[i].scheduledEnd))
                    }
                }
                is BlockListEvent.DeleteBlock -> {
                    sessions.deleteBlock(event.block)
                    val rest = sessions.blocksNow(sid)
                    if (rest.isNotEmpty()) {
                        val anchor = rest.first().scheduledStart
                        sessions.saveBlocks(rescheduler.cascade(rest, 0, anchor))
                    }
                }
                BlockListEvent.StartChain -> {
                    if (sessions.blocksNow(sid).size < SessionRepository.MIN_BLOCKS) {
                        error.value = "Add at least ${SessionRepository.MIN_BLOCKS} block first."
                    } else {
                        engine.start(sid)
                        ServiceLauncher.startTimer(context)
                    }
                }
                BlockListEvent.StopChain -> engine.stop()
                is BlockListEvent.ReorderBlock -> reorder(sid, event.block, event.delta)
                BlockListEvent.CompleteBlock -> engine.completeActive()
                BlockListEvent.DismissError -> { error.value = null }
            }
        }
    }

    private suspend fun reorder(sid: Long, block: TimeBlock, delta: Int) {
        val list = sessions.blocksNow(sid).toMutableList()
        val from = list.indexOfFirst { it.id == block.id }
        val to = from + delta
        if (from < 0 || to !in list.indices) return
        // Blocks already started or finished keep their place.
        if (list[from].actualStart != null || list[to].actualStart != null) return
        val moved = list.removeAt(from)
        list.add(to, moved)
        val anchor = list.minOf { it.scheduledStart }
        val reindexed = list.mapIndexed { i, b -> b.copy(orderIndex = i) }
        sessions.saveBlocks(rescheduler.cascade(reindexed, 0, anchor))
    }

    private fun minutesToMs(minutes: Int): Long = minutes.coerceIn(1, 480) * 60_000L
}
