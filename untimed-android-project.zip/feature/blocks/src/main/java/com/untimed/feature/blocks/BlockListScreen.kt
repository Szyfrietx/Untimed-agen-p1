// Untimed v1.0.0 | 2026-10-06 | P-UNTIMED-ANDROID-001
package com.untimed.feature.blocks

import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Button
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.untimed.core.model.TimeBlock
import com.untimed.core.model.formatClock
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs

@Composable
fun BlockListScreen(viewModel: BlockListViewModel = hiltViewModel()) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    BlockListContent(state, viewModel::onEvent)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun BlockListContent(state: BlockListUiState, onEvent: (BlockListEvent) -> Unit) {
    var sheetFor by remember { mutableStateOf<TimeBlock?>(null) }
    var adding by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Blocks") },
                actions = {
                    if (state.isSequentialMode) {
                        TextButton(onClick = { onEvent(BlockListEvent.StopChain) }) { Text("Stop chain") }
                    } else {
                        TextButton(onClick = { onEvent(BlockListEvent.StartChain) }) { Text("Start chain") }
                    }
                },
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = { adding = true }) { Icon(Icons.Default.Add, contentDescription = "Add block") }
        },
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            state.error?.let {
                Text(
                    it,
                    color = MaterialTheme.colorScheme.error,
                    modifier = Modifier.padding(16.dp),
                )
            }
            if (state.blocks.isEmpty()) {
                Text("No blocks yet. Add up to 20, then start the chain.", Modifier.padding(16.dp))
            }
            LazyColumn(
                contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                items(state.blocks, key = { it.id }) { block ->
                    BlockCard(
                        block = block,
                        active = block.id == state.activeBlockId,
                        remainingMs = state.activeRemainingMs,
                        onEdit = { sheetFor = block },
                        onDelete = { onEvent(BlockListEvent.DeleteBlock(block)) },
                        onMove = { onEvent(BlockListEvent.ReorderBlock(block, it)) },
                        onComplete = { onEvent(BlockListEvent.CompleteBlock) },
                    )
                }
            }
        }
    }

    if (adding) {
        BlockEditSheet(
            initial = null,
            onDismiss = { adding = false },
            onSave = { title, minutes, auto ->
                onEvent(BlockListEvent.AddBlock(title, minutes, auto))
                adding = false
            },
        )
    }
    sheetFor?.let { block ->
        BlockEditSheet(
            initial = block,
            onDismiss = { sheetFor = null },
            onSave = { title, minutes, auto ->
                onEvent(BlockListEvent.EditBlock(block, title, minutes, auto))
                sheetFor = null
            },
        )
    }
}

private val timeFormat = SimpleDateFormat("HH:mm", Locale.getDefault())

@Composable
private fun BlockCard(
    block: TimeBlock,
    active: Boolean,
    remainingMs: Long,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    onMove: (Int) -> Unit,
    onComplete: () -> Unit,
) {
    var heightPx by remember { mutableIntStateOf(0) }
    val container = if (active) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant
    Card(
        Modifier.fillMaxWidth().onSizeChanged { heightPx = it.height },
        colors = CardDefaults.cardColors(containerColor = container),
    ) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                // Drag handle: dragging a little over half the card height swaps with the neighbour.
                Text(
                    "\u2261",
                    style = MaterialTheme.typography.headlineSmall,
                    modifier = Modifier.pointerInput(block.id) {
                        var travelled = 0f
                        detectVerticalDragGestures(
                            onDragStart = { travelled = 0f },
                            onDragEnd = { travelled = 0f },
                            onDragCancel = { travelled = 0f },
                        ) { change, dy ->
                            change.consume()
                            travelled += dy
                            if (heightPx > 0 && abs(travelled) > heightPx * 0.6f) {
                                onMove(if (travelled > 0) 1 else -1)
                                travelled = 0f
                            }
                        }
                    },
                )
                Text(block.title, style = MaterialTheme.typography.titleMedium)
            }
            Text(
                "${timeFormat.format(Date(block.scheduledStart))} to ${timeFormat.format(Date(block.scheduledEnd))}" +
                    " (${block.durationMs / 60_000} min)" + if (block.autoAdvance) "" else ", manual advance",
                style = MaterialTheme.typography.bodyMedium,
            )
            when {
                active -> Text("Remaining ${formatClock(remainingMs)}", style = MaterialTheme.typography.titleSmall)
                block.actualEnd != null -> Text("Done", style = MaterialTheme.typography.labelMedium)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                if (active) TextButton(onClick = onComplete) { Text("Done now") }
                TextButton(onClick = { onMove(-1) }) { Text("Up") }
                TextButton(onClick = { onMove(1) }) { Text("Down") }
                TextButton(onClick = onEdit) { Text("Edit") }
                TextButton(onClick = onDelete) { Text("Delete") }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun BlockEditSheet(
    initial: TimeBlock?,
    onDismiss: () -> Unit,
    onSave: (title: String, minutes: Int, autoAdvance: Boolean) -> Unit,
) {
    var title by remember { mutableStateOf(initial?.title ?: "") }
    var minutes by remember { mutableStateOf((initial?.let { it.durationMs / 60_000 } ?: 25L).toString()) }
    var auto by remember { mutableStateOf(initial?.autoAdvance ?: true) }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(Modifier.padding(16.dp).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(if (initial == null) "New block" else "Edit block", style = MaterialTheme.typography.titleLarge)
            OutlinedTextField(title, { title = it }, label = { Text("Title") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(
                value = minutes,
                onValueChange = { minutes = it.filter(Char::isDigit).take(3) },
                label = { Text("Minutes") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth(),
            )
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Switch(checked = auto, onCheckedChange = { auto = it })
                Text("Advance automatically")
            }
            Button(
                onClick = { onSave(title, minutes.toIntOrNull() ?: 25, auto) },
                modifier = Modifier.fillMaxWidth(),
            ) { Text("Save") }
        }
    }
}
