// Untimed v1.0.0 | 2026-10-06 | P-UNTIMED-ANDROID-001
package com.untimed.feature.bank

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.untimed.core.engine.SurgeCalculator
import com.untimed.core.model.BucketTag
import com.untimed.core.model.RatioPreset
import com.untimed.core.model.SurgeTier
import com.untimed.core.model.formatClock
import com.untimed.core.ui.components.FuelTankVisualizer
import com.untimed.core.ui.components.RatioSwitcher

/** Tank capacity shown on the gauge: 120 minutes of banked time [ASSUMPTION: B-04]. */
private const val TANK_CAPACITY_MS = 120 * 60 * 1000f

@Composable
fun TimeBankScreen(viewModel: TimeBankViewModel = hiltViewModel()) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val presets by viewModel.presets.collectAsStateWithLifecycle()
    val tags by viewModel.tags.collectAsStateWithLifecycle()
    TimeBankContent(state, presets, tags, viewModel::onEvent)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TimeBankContent(
    state: TimeBankUiState,
    presets: List<RatioPreset>,
    tags: List<BucketTag>,
    onEvent: (TimeBankEvent) -> Unit,
) {
    Scaffold(topBar = { TopAppBar(title = { Text("Time Bank") }) }) { padding ->
        Column(Modifier.padding(padding).fillMaxSize().padding(16.dp)) {
            FuelTankVisualizer(
                fillFraction = state.remainingMs / TANK_CAPACITY_MS,
                label = formatClock(state.remainingMs),
                modifier = Modifier.fillMaxWidth().weight(0.4f),
            )
            Spacer(Modifier.height(12.dp))
            Column(
                modifier = Modifier.weight(0.6f).fillMaxWidth().verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                SurgeIndicator(state)
                RatioSwitcher(presets, state.presetId, { onEvent(TimeBankEvent.SetRatio(it)) })
                BucketRow(tags, state.bucketTag) { onEvent(TimeBankEvent.SetBucket(it)) }
                PlaybackControls(state, onEvent)
                CashOutButton(enabled = state.remainingMs > 0 && !state.isResting) { onEvent(TimeBankEvent.CashOut) }
            }
        }
    }
}

@Composable
private fun SurgeIndicator(state: TimeBankUiState) {
    val label = when {
        state.isResting -> "Resting: bank is draining"
        state.isRunning && state.surgeTier != SurgeTier.NONE ->
            "Surge x${state.surgeTier.multiplier} active"
        state.isRunning -> {
            val toSurge = (SurgeCalculator.TIER_1_MS - state.elapsedMs).coerceAtLeast(0)
            "Working ${formatClock(state.elapsedMs)} (surge in ${formatClock(toSurge)})"
        }
        else -> "Ratio ${state.ratio}:1 (work : rest)"
    }
    val color = if (state.surgeTier == SurgeTier.NONE) MaterialTheme.colorScheme.onSurfaceVariant
    else MaterialTheme.colorScheme.tertiary
    Text(label, style = MaterialTheme.typography.titleMedium, color = color)
}

@Composable
private fun BucketRow(tags: List<BucketTag>, selected: BucketTag?, onSelect: (BucketTag?) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        FilterChip(selected = selected == null, onClick = { onSelect(null) }, label = { Text("No bucket") })
        tags.forEach { tag -> BucketTagChip(tag, tag.id == selected?.id) { onSelect(tag) } }
    }
}

@Composable
private fun BucketTagChip(tag: BucketTag, selected: Boolean, onClick: () -> Unit) {
    FilterChip(
        selected = selected,
        onClick = onClick,
        label = { Text("${tag.name} x${"%.1f".format(tag.weight)}") },
    )
}

@Composable
private fun PlaybackControls(state: TimeBankUiState, onEvent: (TimeBankEvent) -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        if (state.isRunning) {
            FilledTonalButton(onClick = { onEvent(TimeBankEvent.Pause) }, modifier = Modifier.weight(1f)) {
                Text("Pause")
            }
        } else {
            Button(onClick = { onEvent(TimeBankEvent.Start) }, modifier = Modifier.weight(1f)) {
                Text("Start")
            }
        }
        OutlinedButton(onClick = { onEvent(TimeBankEvent.Reset) }, modifier = Modifier.weight(1f)) {
            Text("Time Dump")
        }
    }
}

@Composable
private fun CashOutButton(enabled: Boolean, onClick: () -> Unit) {
    Button(onClick = onClick, enabled = enabled, modifier = Modifier.fillMaxWidth()) {
        Text("Cash out and rest")
    }
}
