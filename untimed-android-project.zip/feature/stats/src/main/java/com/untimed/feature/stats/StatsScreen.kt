// Untimed v1.0.0 | 2026-10-06 | P-UNTIMED-ANDROID-001
package com.untimed.feature.stats

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.untimed.core.data.dayKeyDaysAgo
import com.untimed.core.model.Session
import com.untimed.core.model.formatClock
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun StatsScreen(viewModel: StatsViewModel = hiltViewModel()) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    StatsContent(state, viewModel::onEvent)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun StatsContent(state: StatsUiState, onEvent: (StatsEvent) -> Unit) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Stats") },
                actions = { TextButton(onClick = { onEvent(StatsEvent.ClearHistory) }) { Text("Clear history") } },
            )
        },
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            TotalFocusCard(state)
            StreakCalendar(state.activeDays)
            SessionList(state.sessions, Modifier.weight(1f))
        }
    }
}

@Composable
private fun TotalFocusCard(state: StatsUiState) {
    Card(Modifier.fillMaxWidth()) {
        Row(Modifier.padding(16.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Column {
                Text("Total focus", style = MaterialTheme.typography.labelMedium)
                Text(formatClock(state.totalFocusMs), style = MaterialTheme.typography.headlineMedium)
            }
            Column(horizontalAlignment = Alignment.End) {
                Text("Streak", style = MaterialTheme.typography.labelMedium)
                Text("${state.streakCount} d", style = MaterialTheme.typography.headlineMedium)
            }
        }
    }
}

/** Last 28 days, oldest first, seven per row. Filled cells are days with a session. */
@Composable
fun StreakCalendar(activeDays: Set<String>, modifier: Modifier = Modifier) {
    val days = (27 downTo 0).map { dayKeyDaysAgo(it) }
    Column(modifier, verticalArrangement = Arrangement.spacedBy(4.dp)) {
        days.chunked(7).forEach { week ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                week.forEach { key ->
                    val on = key in activeDays
                    Box(
                        Modifier
                            .weight(1f)
                            .aspectRatio(1f)
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (on) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant),
                    )
                }
            }
        }
    }
}

private val rowFormat = SimpleDateFormat("EEE d MMM, HH:mm", Locale.getDefault())

@Composable
private fun SessionList(sessions: List<Session>, modifier: Modifier = Modifier) {
    if (sessions.isEmpty()) {
        Text("No sessions yet.", modifier)
        return
    }
    LazyColumn(modifier, verticalArrangement = Arrangement.spacedBy(8.dp)) {
        items(sessions, key = { it.id }) { s ->
            Card(Modifier.fillMaxWidth()) {
                Row(Modifier.padding(12.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(rowFormat.format(Date(s.startTime)))
                    Text(if (s.isActive) "In progress" else "${formatClock(s.durationMs)}  x${s.surgeMultiplier}")
                }
            }
        }
    }
}
