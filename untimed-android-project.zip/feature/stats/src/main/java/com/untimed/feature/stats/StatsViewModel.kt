// Untimed v1.0.0 | 2026-10-06 | P-UNTIMED-ANDROID-001
package com.untimed.feature.stats

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.untimed.core.data.SessionRepository
import com.untimed.core.data.dayKey
import com.untimed.core.model.Session
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.Calendar
import javax.inject.Inject

data class StatsUiState(
    val streakCount: Int = 0,
    val sessions: List<Session> = emptyList(),
    val totalFocusMs: Long = 0,
    val activeDays: Set<String> = emptySet(),
)

sealed interface StatsEvent {
    data object LoadStats : StatsEvent
    data object ClearHistory : StatsEvent
}

@OptIn(ExperimentalCoroutinesApi::class)
@HiltViewModel
class StatsViewModel @Inject constructor(
    private val sessions: SessionRepository,
) : ViewModel() {

    private val reload = MutableStateFlow(0)

    val uiState: StateFlow<StatsUiState> = reload.flatMapLatest {
        combine(sessions.bankSessions, sessions.streaks) { list, streaks ->
            val days = streaks.filter { it.hasSession }.map { it.date }.toSet()
            StatsUiState(
                streakCount = streakLength(days),
                sessions = list,
                totalFocusMs = list.sumOf { it.durationMs },
                activeDays = days,
            )
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), StatsUiState())

    fun onEvent(event: StatsEvent) {
        when (event) {
            StatsEvent.LoadStats -> reload.value += 1
            StatsEvent.ClearHistory -> viewModelScope.launch { sessions.clearHistory() }
        }
    }

    /** Consecutive days with a session, ending today (or yesterday if today has none yet). */
    private fun streakLength(days: Set<String>): Int {
        val cal = Calendar.getInstance()
        if (dayKey(cal.timeInMillis) !in days) cal.add(Calendar.DAY_OF_YEAR, -1)
        var count = 0
        while (dayKey(cal.timeInMillis) in days) {
            count++
            cal.add(Calendar.DAY_OF_YEAR, -1)
        }
        return count
    }
}
