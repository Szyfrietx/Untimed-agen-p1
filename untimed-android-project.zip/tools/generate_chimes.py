# Untimed v1.0.0 | 2026-10-06 | P-UNTIMED-ANDROID-001
"""Generates the three placeholder chimes as OGG Vorbis (A-16, T-06).
Usage: pip install numpy soundfile && python tools/generate_chimes.py
Replace the output in app/src/main/res/raw/ with real recordings at any time; names must stay the same.
"""
import numpy as np
import soundfile as sf

RATE = 44100
OUT = "app/src/main/res/raw/"

def chime(freqs, seconds, decay):
    t = np.linspace(0, seconds, int(RATE * seconds), endpoint=False)
    wave = sum(np.sin(2 * np.pi * f * t) for f in freqs) / len(freqs)
    return (0.6 * wave * np.exp(-decay * t)).astype("float32")

SPECS = {
    "chime_boundary.ogg": ([660, 990], 2.0, 2.2),   # 2 s
    "chime_depletion.ogg": ([440, 330, 220], 3.0, 1.4),  # 3 s
    "chime_alert.ogg": ([880], 1.0, 4.0),          # 1 s
}

for name, (freqs, seconds, decay) in SPECS.items():
    sf.write(OUT + name, chime(freqs, seconds, decay), RATE, format="OGG", subtype="VORBIS")
    print("wrote", OUT + name)
