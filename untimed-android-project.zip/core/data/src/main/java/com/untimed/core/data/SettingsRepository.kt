// Untimed v1.0.0 | 2026-10-06 | P-UNTIMED-ANDROID-001
package com.untimed.core.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

val DEFAULT_PALETTE = listOf("#FF6750A4", "#FF625B71", "#FF7D5260")

/** Engine state written to disk so a killed process or a reboot can resume (see TimeBankEngine.restore). */
data class EngineSnapshot(
    val bankMs: Long = 0,
    val mode: String = "IDLE",
    val elapsedMs: Long = 0,
    /** Wall-clock time of the write, used to drain a rest countdown across a restart. */
    val savedAt: Long = 0,
)

data class AppSettings(
    val primaryHex: String = DEFAULT_PALETTE[0],
    val secondaryHex: String = DEFAULT_PALETTE[1],
    val tertiaryHex: String = DEFAULT_PALETTE[2],
    /** Share of the bank removed at midnight. User range 10–90 (CF-05). */
    val decayPercent: Int = 50,
    val overlayEnabled: Boolean = false,
    val wakeLockEnabled: Boolean = false,
    val soundEnabled: Boolean = true,
    val hapticEnabled: Boolean = true,
) {
    val palette: List<String> get() = listOf(primaryHex, secondaryHex, tertiaryHex)
}

private val Context.untimedStore: DataStore<Preferences> by preferencesDataStore(name = "untimed_settings")

@Singleton
class SettingsRepository @Inject constructor(
    @ApplicationContext private val context: Context,
) {
    private object Keys {
        val PRIMARY = stringPreferencesKey("palette_primary")
        val SECONDARY = stringPreferencesKey("palette_secondary")
        val TERTIARY = stringPreferencesKey("palette_tertiary")
        val DECAY = intPreferencesKey("decay_percent")
        val OVERLAY = booleanPreferencesKey("overlay_enabled")
        val WAKE = booleanPreferencesKey("wake_lock_enabled")
        val SOUND = booleanPreferencesKey("sound_enabled")
        val HAPTIC = booleanPreferencesKey("haptic_enabled")
        val BANK_MS = longPreferencesKey("bank_ms")
        val PRESET_ID = longPreferencesKey("selected_preset_id")
        val TAG_ID = longPreferencesKey("selected_tag_id")
        val SNAP_MODE = stringPreferencesKey("snapshot_mode")
        val SNAP_ELAPSED = longPreferencesKey("snapshot_elapsed_ms")
        val SNAP_AT = longPreferencesKey("snapshot_saved_at")
        val LAST_DECAY = stringPreferencesKey("last_decay_day")
    }

    private val store get() = context.untimedStore

    val settings: Flow<AppSettings> = store.data.map { p ->
        AppSettings(
            primaryHex = p[Keys.PRIMARY] ?: DEFAULT_PALETTE[0],
            secondaryHex = p[Keys.SECONDARY] ?: DEFAULT_PALETTE[1],
            tertiaryHex = p[Keys.TERTIARY] ?: DEFAULT_PALETTE[2],
            decayPercent = p[Keys.DECAY] ?: 50,
            overlayEnabled = p[Keys.OVERLAY] ?: false,
            wakeLockEnabled = p[Keys.WAKE] ?: false,
            soundEnabled = p[Keys.SOUND] ?: true,
            hapticEnabled = p[Keys.HAPTIC] ?: true,
        )
    }

    val bankMs: Flow<Long> = store.data.map { it[Keys.BANK_MS] ?: 0L }
    val selectedPresetId: Flow<Long> = store.data.map { it[Keys.PRESET_ID] ?: -1L }
    val selectedTagId: Flow<Long> = store.data.map { it[Keys.TAG_ID] ?: -1L }
    val snapshot: Flow<EngineSnapshot> = store.data.map {
        EngineSnapshot(
            bankMs = it[Keys.BANK_MS] ?: 0L,
            mode = it[Keys.SNAP_MODE] ?: "IDLE",
            elapsedMs = it[Keys.SNAP_ELAPSED] ?: 0L,
            savedAt = it[Keys.SNAP_AT] ?: 0L,
        )
    }
    val lastDecayDay: Flow<String> = store.data.map { it[Keys.LAST_DECAY] ?: "" }

    suspend fun setPalette(palette: List<String>) = store.edit {
        it[Keys.PRIMARY] = palette.getOrElse(0) { DEFAULT_PALETTE[0] }
        it[Keys.SECONDARY] = palette.getOrElse(1) { DEFAULT_PALETTE[1] }
        it[Keys.TERTIARY] = palette.getOrElse(2) { DEFAULT_PALETTE[2] }
    }.let { }

    suspend fun setDecayPercent(value: Int) = store.edit { it[Keys.DECAY] = value.coerceIn(10, 90) }.let { }
    suspend fun setOverlayEnabled(v: Boolean) = store.edit { it[Keys.OVERLAY] = v }.let { }
    suspend fun setWakeLockEnabled(v: Boolean) = store.edit { it[Keys.WAKE] = v }.let { }
    suspend fun setSoundEnabled(v: Boolean) = store.edit { it[Keys.SOUND] = v }.let { }
    suspend fun setHapticEnabled(v: Boolean) = store.edit { it[Keys.HAPTIC] = v }.let { }
    suspend fun setBankMs(v: Long) = store.edit { it[Keys.BANK_MS] = v.coerceAtLeast(0L) }.let { }
    suspend fun setSelectedPresetId(v: Long) = store.edit { it[Keys.PRESET_ID] = v }.let { }
    suspend fun setSelectedTagId(v: Long) = store.edit { it[Keys.TAG_ID] = v }.let { }
    suspend fun setLastDecayDay(day: String) = store.edit { it[Keys.LAST_DECAY] = day }.let { }

    suspend fun saveSnapshot(s: EngineSnapshot) = store.edit {
        it[Keys.BANK_MS] = s.bankMs.coerceAtLeast(0L)
        it[Keys.SNAP_MODE] = s.mode
        it[Keys.SNAP_ELAPSED] = s.elapsedMs
        it[Keys.SNAP_AT] = s.savedAt
    }.let { }
}
