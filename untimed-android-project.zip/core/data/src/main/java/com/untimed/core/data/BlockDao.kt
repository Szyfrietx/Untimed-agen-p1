// Untimed v1.0.0 | 2026-10-06 | P-UNTIMED-ANDROID-001
package com.untimed.core.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import com.untimed.core.model.TimeBlock
import kotlinx.coroutines.flow.Flow

@Dao
interface BlockDao {
    @Insert
    suspend fun insert(block: TimeBlock): Long

    @Update
    suspend fun update(block: TimeBlock)

    @Update
    suspend fun updateAll(blocks: List<TimeBlock>)

    @Delete
    suspend fun delete(block: TimeBlock)

    @Query("SELECT * FROM time_blocks WHERE id = :id")
    suspend fun byId(id: Long): TimeBlock?

    @Query("SELECT * FROM time_blocks WHERE sessionId = :sessionId ORDER BY orderIndex ASC")
    fun observeBySession(sessionId: Long): Flow<List<TimeBlock>>

    @Query("SELECT * FROM time_blocks WHERE sessionId = :sessionId ORDER BY orderIndex ASC")
    suspend fun bySession(sessionId: Long): List<TimeBlock>
}
