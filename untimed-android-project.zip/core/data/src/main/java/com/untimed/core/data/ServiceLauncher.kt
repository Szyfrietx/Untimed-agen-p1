// Untimed v1.0.0 | 2026-10-06 | P-UNTIMED-ANDROID-001
package com.untimed.core.data

import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat

/**
 * Starts the foreground services by class name. Feature modules do not depend on :core:service
 * (Table B), so they reach the services through this indirection instead of a class reference.
 */
object ServiceLauncher {
    const val TIMER_SERVICE = "com.untimed.core.service.TimerForegroundService"
    const val OVERLAY_SERVICE = "com.untimed.core.service.OverlayBubbleService"

    fun startTimer(context: Context) {
        ContextCompat.startForegroundService(context, intentFor(context, TIMER_SERVICE))
    }

    fun setOverlay(context: Context, enabled: Boolean) {
        val intent = intentFor(context, OVERLAY_SERVICE)
        if (enabled) ContextCompat.startForegroundService(context, intent) else context.stopService(intent)
    }

    private fun intentFor(context: Context, className: String) =
        Intent().setClassName(context.packageName, className)
}
