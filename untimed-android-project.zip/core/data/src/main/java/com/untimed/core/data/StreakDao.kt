// Untimed v1.0.0 | 2026-10-06 | P-UNTIMED-ANDROID-001
package com.untimed.core.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.untimed.core.model.StreakRecord
import kotlinx.coroutines.flow.Flow

@Dao
interface StreakDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(record: StreakRecord)

    @Query("SELECT * FROM streak_records WHERE date = :date")
    suspend fun byDate(date: String): StreakRecord?

    @Query("SELECT * FROM streak_records ORDER BY date DESC")
    fun observeAll(): Flow<List<StreakRecord>>

    @Query("DELETE FROM streak_records")
    suspend fun deleteAll()
}
