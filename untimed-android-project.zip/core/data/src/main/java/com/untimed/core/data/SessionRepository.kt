// Untimed v1.0.0 | 2026-10-06 | P-UNTIMED-ANDROID-001
package com.untimed.core.data

import com.untimed.core.model.BucketTag
import com.untimed.core.model.RatioPreset
import com.untimed.core.model.Session
import com.untimed.core.model.StreakRecord
import com.untimed.core.model.TimeBlock
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.math.roundToInt

/** Local-time day key, YYYY-MM-DD. Uses SimpleDateFormat because minSdk 24 lacks java.time. */
fun dayKey(ms: Long = System.currentTimeMillis()): String =
    SimpleDateFormat("yyyy-MM-dd", Locale.US).format(ms)

/** Whole days from [fromKey] to [toKey], both YYYY-MM-DD. */
fun daysBetween(fromKey: String, toKey: String): Int {
    val format = SimpleDateFormat("yyyy-MM-dd", Locale.US)
    val from = format.parse(fromKey)?.time ?: return 0
    val to = format.parse(toKey)?.time ?: return 0
    return ((to - from) / 86_400_000.0).roundToInt() // rounding absorbs DST hour shifts
}

/** Day key for `daysAgo` days before today. */
fun dayKeyDaysAgo(daysAgo: Int): String {
    val cal = Calendar.getInstance()
    cal.add(Calendar.DAY_OF_YEAR, -daysAgo)
    return dayKey(cal.timeInMillis)
}

@Singleton
class SessionRepository @Inject constructor(
    private val sessionDao: SessionDao,
    private val blockDao: BlockDao,
    private val tagDao: BucketTagDao,
    private val presetDao: RatioPresetDao,
    private val streakDao: StreakDao,
) {
    companion object {
        const val MAX_BLOCKS = 20
        const val MIN_BLOCKS = 1
    }

    val presets = presetDao.observeAll()
    val tags = tagDao.observeAll()
    val bankSessions = sessionDao.observeBankSessions()
    val streaks = streakDao.observeAll()

    suspend fun presetById(id: Long): RatioPreset? = presetDao.byId(id)
    suspend fun defaultPreset(): RatioPreset? = presetDao.findDefault()
    suspend fun tagById(id: Long): BucketTag? = tagDao.byId(id)

    suspend fun upsertTag(name: String, weight: Float, colorHex: String): Long {
        if (name.isBlank()) return -1L
        val snapped = (weight.coerceIn(0.5f, 2.0f) * 10).roundToInt() / 10f
        return tagDao.upsert(BucketTag(name = name.trim(), weight = snapped, colorHex = colorHex))
    }

    // ---- bank sessions ----
    suspend fun startBankSession(presetId: Long?, tagId: Long?): Long {
        val resolvedPreset = presetId ?: presetDao.findDefault()?.id
        val id = sessionDao.insert(
            Session(startTime = System.currentTimeMillis(), ratioPresetId = resolvedPreset, bucketTagId = tagId, kind = Session.KIND_BANK),
        )
        markToday()
        return id
    }

    suspend fun finishBankSession(id: Long, endTime: Long, durationMs: Long, surgeMultiplier: Float) {
        sessionDao.byId(id)?.let {
            sessionDao.update(
                it.copy(endTime = endTime, durationMs = durationMs, surgeMultiplier = surgeMultiplier, isActive = false),
            )
        }
    }

    suspend fun closeOrphanBankSessions(elapsedMs: Long) =
        sessionDao.closeOrphanBankSessions(System.currentTimeMillis(), elapsedMs)

    /** Adds a work:rest preset (rest fixed at 1). Skips ratios that already exist. */
    suspend fun addPreset(workRatio: Int) {
        val ratio = workRatio.coerceIn(1, 10)
        if (presetDao.countByRatio(ratio) == 0) presetDao.upsert(RatioPreset(label = "$ratio:1", workRatio = ratio))
    }

    private suspend fun markToday() {
        val key = dayKey()
        val current = streakDao.byDate(key)
        streakDao.upsert(StreakRecord(key, true, (current?.sessionCount ?: 0) + 1))
    }

    suspend fun clearHistory() {
        sessionDao.deleteFinished()
        streakDao.deleteAll()
    }

    // ---- chain sessions and blocks ----
    suspend fun chainSessionId(): Long =
        sessionDao.activeChainSession()?.id
            ?: sessionDao.insert(Session(startTime = System.currentTimeMillis(), isActive = true, kind = Session.KIND_CHAIN))

    fun observeBlocks(sessionId: Long) = blockDao.observeBySession(sessionId)
    suspend fun blocksNow(sessionId: Long): List<TimeBlock> = blockDao.bySession(sessionId)
    suspend fun blockById(id: Long): TimeBlock? = blockDao.byId(id)
    suspend fun saveBlocks(blocks: List<TimeBlock>) = blockDao.updateAll(blocks)

    /** Returns false when the chain already holds [MAX_BLOCKS]. */
    suspend fun addBlock(sessionId: Long, title: String, durationMs: Long, autoAdvance: Boolean): Boolean {
        val existing = blockDao.bySession(sessionId)
        if (existing.size >= MAX_BLOCKS) return false
        val now = System.currentTimeMillis()
        val start = existing.lastOrNull()?.scheduledEnd?.coerceAtLeast(now) ?: now
        blockDao.insert(
            TimeBlock(
                sessionId = sessionId,
                title = title,
                scheduledStart = start,
                scheduledEnd = start + durationMs,
                orderIndex = existing.size,
                autoAdvance = autoAdvance,
            ),
        )
        return true
    }

    suspend fun deleteBlock(block: TimeBlock) {
        blockDao.delete(block)
        val rest = blockDao.bySession(block.sessionId).mapIndexed { i, b -> b.copy(orderIndex = i) }
        blockDao.updateAll(rest)
    }
}
