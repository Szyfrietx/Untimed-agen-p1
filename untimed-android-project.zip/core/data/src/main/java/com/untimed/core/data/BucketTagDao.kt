// Untimed v1.0.0 | 2026-10-06 | P-UNTIMED-ANDROID-001
package com.untimed.core.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.untimed.core.model.BucketTag
import kotlinx.coroutines.flow.Flow

@Dao
interface BucketTagDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(tag: BucketTag): Long

    @Query("SELECT * FROM bucket_tags ORDER BY name ASC")
    fun observeAll(): Flow<List<BucketTag>>

    @Query("SELECT * FROM bucket_tags WHERE id = :id")
    suspend fun byId(id: Long): BucketTag?
}
