// Untimed v1.0.0 | 2026-10-06 | P-UNTIMED-ANDROID-001
package com.untimed.core.data

import androidx.room.Database
import androidx.room.RoomDatabase
import com.untimed.core.model.BucketTag
import com.untimed.core.model.RatioPreset
import com.untimed.core.model.Session
import com.untimed.core.model.StreakRecord
import com.untimed.core.model.TimeBlock

@Database(
    entities = [Session::class, TimeBlock::class, BucketTag::class, RatioPreset::class, StreakRecord::class],
    version = 1,
    exportSchema = false,
)
abstract class UntimedDatabase : RoomDatabase() {
    abstract fun sessionDao(): SessionDao
    abstract fun blockDao(): BlockDao
    abstract fun bucketTagDao(): BucketTagDao
    abstract fun ratioPresetDao(): RatioPresetDao
    abstract fun streakDao(): StreakDao
}
