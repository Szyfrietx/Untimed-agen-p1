// Untimed v1.0.0 | 2026-10-06 | P-UNTIMED-ANDROID-001
package com.untimed.core.service

import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import javax.inject.Inject
import javax.inject.Singleton

/** Single 200 ms pulse (Q4=A). */
@Singleton
class HapticFeedbackHelper @Inject constructor(private val vibrator: Vibrator) {
    fun pulse() {
        if (!vibrator.hasVibrator()) return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator.vibrate(VibrationEffect.createOneShot(PULSE_MS, VibrationEffect.DEFAULT_AMPLITUDE))
        } else {
            @Suppress("DEPRECATION")
            vibrator.vibrate(PULSE_MS)
        }
    }

    private companion object {
        const val PULSE_MS = 200L
    }
}
