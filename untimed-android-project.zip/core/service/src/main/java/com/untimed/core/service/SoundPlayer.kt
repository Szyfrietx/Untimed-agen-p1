// Untimed v1.0.0 | 2026-10-06 | P-UNTIMED-ANDROID-001
package com.untimed.core.service

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool
import dagger.hilt.android.qualifiers.ApplicationContext
import java.util.concurrent.ConcurrentHashMap
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Plays the three bundled chimes from res/raw. Resources resolve by name at runtime because
 * the files live in :app and this module cannot reference its R class.
 */
@Singleton
class SoundPlayer @Inject constructor(
    @ApplicationContext private val context: Context,
) {
    companion object {
        const val BOUNDARY = "chime_boundary"
        const val DEPLETION = "chime_depletion"
        const val ALERT = "chime_alert"
    }

    private val pool: SoundPool = SoundPool.Builder()
        .setMaxStreams(3)
        .setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_NOTIFICATION_EVENT)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build(),
        )
        .build()
    private val ids = ConcurrentHashMap<String, Int>()
    private val ready = ConcurrentHashMap.newKeySet<Int>()

    init {
        pool.setOnLoadCompleteListener { _, sampleId, status -> if (status == 0) ready.add(sampleId) }
        listOf(BOUNDARY, DEPLETION, ALERT).forEach { name ->
            val res = context.resources.getIdentifier(name, "raw", context.packageName)
            if (res != 0) ids[name] = pool.load(context, res, 1)
        }
    }

    fun play(name: String) {
        val id = ids[name] ?: return
        if (id in ready) pool.play(id, 1f, 1f, 1, 0, 1f)
    }
}
