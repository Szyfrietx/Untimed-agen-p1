// Untimed v1.0.0 | 2026-10-06 | P-UNTIMED-ANDROID-001
package com.untimed.core.engine

import com.untimed.core.model.SurgeTier
import org.junit.Assert.assertEquals
import org.junit.Test

class SurgeCalculatorTest {
    private val calc = SurgeCalculator()
    private val minute = 60_000L

    @Test fun belowThirtyMinutesHasNoSurge() = assertEquals(SurgeTier.NONE, calc.tierFor(29 * minute + 59_999))
    @Test fun thirtyMinutesIsTierOne() = assertEquals(SurgeTier.TIER_1, calc.tierFor(30 * minute))
    @Test fun sixtyMinutesIsTierTwo() = assertEquals(SurgeTier.TIER_2, calc.tierFor(60 * minute))
    @Test fun multipliersMatchSpec() {
        assertEquals(1.5f, SurgeTier.TIER_1.multiplier, 0f)
        assertEquals(2.0f, SurgeTier.TIER_2.multiplier, 0f)
    }
}
