// Untimed v1.0.0 | 2026-10-06 | P-UNTIMED-ANDROID-001
package com.untimed.core.engine

import com.untimed.core.model.TimeBlock
import org.junit.Assert.assertEquals
import org.junit.Test

class ElasticReschedulerTest {
    private val rescheduler = ElasticRescheduler()
    private val minute = 60_000L

    private fun blocks() = listOf(
        TimeBlock(id = 1, sessionId = 1, title = "A", scheduledStart = 0, scheduledEnd = 10 * minute, orderIndex = 0),
        TimeBlock(id = 2, sessionId = 1, title = "B", scheduledStart = 10 * minute, scheduledEnd = 30 * minute, orderIndex = 1),
        TimeBlock(id = 3, sessionId = 1, title = "C", scheduledStart = 30 * minute, scheduledEnd = 45 * minute, orderIndex = 2),
    )

    @Test fun overrunPushesFollowersBack() {
        val out = rescheduler.cascade(blocks(), 1, 14 * minute)
        assertEquals(14 * minute, out[1].scheduledStart)
        assertEquals(34 * minute, out[1].scheduledEnd)
        assertEquals(34 * minute, out[2].scheduledStart)
        assertEquals(49 * minute, out[2].scheduledEnd)
    }

    @Test fun earlyCompletionPullsFollowersForward() {
        val out = rescheduler.cascade(blocks(), 1, 6 * minute)
        assertEquals(6 * minute, out[1].scheduledStart)
        assertEquals(26 * minute, out[2].scheduledStart)
    }

    @Test fun blocksBeforeAnchorAreUntouched() {
        val original = blocks()
        assertEquals(original[0], rescheduler.cascade(original, 1, 99 * minute)[0])
    }

    @Test fun durationsArePreserved() {
        val out = rescheduler.cascade(blocks(), 0, 100 * minute)
        assertEquals(listOf(10 * minute, 20 * minute, 15 * minute), out.map { it.scheduledEnd - it.scheduledStart })
    }
}
