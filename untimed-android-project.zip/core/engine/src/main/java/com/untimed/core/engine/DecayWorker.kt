// Untimed v1.0.0 | 2026-10-06 | P-UNTIMED-ANDROID-001
package com.untimed.core.engine

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import dagger.hilt.EntryPoint
import dagger.hilt.InstallIn
import dagger.hilt.android.EntryPointAccessors
import dagger.hilt.components.SingletonComponent
import java.util.Calendar
import java.util.concurrent.TimeUnit

/**
 * Runs daily around local midnight (Q9=A). The engine applies decay per missed midnight and records the
 * last applied day, so late or skipped runs are caught up and repeated runs do nothing.
 */
class DecayWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {

    @EntryPoint
    @InstallIn(SingletonComponent::class)
    interface DecayEntryPoint {
        fun engine(): TimeBankEngine
    }

    override suspend fun doWork(): Result {
        val entry = EntryPointAccessors.fromApplication(applicationContext, DecayEntryPoint::class.java)
        entry.engine().applyPendingDecay()
        return Result.success()
    }

    companion object {
        const val UNIQUE_NAME = "untimed_decay"

        /** 24h period, 1h flex, first run delayed to the next local midnight. Timing is best-effort; see applyPendingDecay. */
        fun schedule(context: Context) {
            val request = PeriodicWorkRequestBuilder<DecayWorker>(24, TimeUnit.HOURS, 1, TimeUnit.HOURS)
                .setInitialDelay(millisUntilNextMidnight(), TimeUnit.MILLISECONDS)
                .build()
            WorkManager.getInstance(context)
                .enqueueUniquePeriodicWork(UNIQUE_NAME, ExistingPeriodicWorkPolicy.KEEP, request)
        }

        private fun millisUntilNextMidnight(): Long {
            val now = Calendar.getInstance()
            val next = (now.clone() as Calendar).apply {
                add(Calendar.DAY_OF_YEAR, 1)
                set(Calendar.HOUR_OF_DAY, 0)
                set(Calendar.MINUTE, 0)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
            }
            return next.timeInMillis - now.timeInMillis
        }
    }
}
