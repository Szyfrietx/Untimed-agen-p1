// Untimed v1.0.0 | 2026-10-06 | P-UNTIMED-ANDROID-001
package com.untimed.core.engine

import com.untimed.core.model.SurgeTier
import javax.inject.Inject

/** Tiered earning surge: 1.5x after 30 continuous minutes, 2.0x after 60 (A-08). */
class SurgeCalculator @Inject constructor() {
    fun tierFor(elapsedMs: Long): SurgeTier = when {
        elapsedMs >= TIER_2_MS -> SurgeTier.TIER_2
        elapsedMs >= TIER_1_MS -> SurgeTier.TIER_1
        else -> SurgeTier.NONE
    }

    companion object {
        const val TIER_1_MS = 30 * 60 * 1000L
        const val TIER_2_MS = 60 * 60 * 1000L
    }
}
