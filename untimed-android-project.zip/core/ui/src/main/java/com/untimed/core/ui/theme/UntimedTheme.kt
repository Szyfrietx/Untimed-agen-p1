// Untimed v1.0.0 | 2026-10-06 | P-UNTIMED-ANDROID-001
package com.untimed.core.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

/**
 * Material 3 theme. With the default palette on Android 12+, dynamic color applies.
 * Any custom palette (primary, secondary, tertiary hex) replaces it.
 */
@Composable
fun UntimedTheme(
    palette: List<String> = DefaultPalette,
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit,
) {
    val context = LocalContext.current
    val useDynamic = palette == DefaultPalette && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S
    val scheme = if (useDynamic) {
        if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
    } else {
        val primary = palette.getOrNull(0).toColorOrDefault(Color(0xFF6750A4))
        val secondary = palette.getOrNull(1).toColorOrDefault(Color(0xFF625B71))
        val tertiary = palette.getOrNull(2).toColorOrDefault(Color(0xFF7D5260))
        if (darkTheme) darkColorScheme(primary = primary, secondary = secondary, tertiary = tertiary)
        else lightColorScheme(primary = primary, secondary = secondary, tertiary = tertiary)
    }
    MaterialTheme(colorScheme = scheme, typography = UntimedTypography, content = content)
}
