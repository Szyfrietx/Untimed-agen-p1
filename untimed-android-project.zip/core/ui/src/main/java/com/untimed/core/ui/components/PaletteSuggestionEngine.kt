// Untimed v1.0.0 | 2026-10-06 | P-UNTIMED-ANDROID-001
package com.untimed.core.ui.components

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb

/** A three-slot palette: primary, secondary, tertiary. */
data class PaletteSuggestion(val name: String, val colors: List<Color>)

/** Complementary, analogous and triadic suggestions from one base color (Q5=A). */
object PaletteSuggestionEngine {
    fun suggest(base: Color): List<PaletteSuggestion> {
        val hsv = FloatArray(3)
        android.graphics.Color.colorToHSV(base.toArgb(), hsv)

        fun rotated(degrees: Float, saturation: Float = hsv[1]): Color {
            val hue = (hsv[0] + degrees + 360f) % 360f
            return Color(android.graphics.Color.HSVToColor(floatArrayOf(hue, saturation, hsv[2])))
        }

        return listOf(
            PaletteSuggestion("Complementary", listOf(base, rotated(180f), rotated(0f, hsv[1] * 0.6f))),
            PaletteSuggestion("Analogous", listOf(base, rotated(30f), rotated(-30f))),
            PaletteSuggestion("Triadic", listOf(base, rotated(120f), rotated(240f))),
        )
    }
}
