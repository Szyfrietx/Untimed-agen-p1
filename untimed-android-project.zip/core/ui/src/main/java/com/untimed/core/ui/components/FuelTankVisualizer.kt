// Untimed v1.0.0 | 2026-10-06 | P-UNTIMED-ANDROID-001
package com.untimed.core.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import kotlin.math.PI
import kotlin.math.sin

/** Vertical fluid gauge with an animated wave on the surface (Q10=A). [fillFraction] is 0..1. */
@Composable
fun FuelTankVisualizer(
    fillFraction: Float,
    modifier: Modifier = Modifier,
    label: String? = null,
    fluidColor: Color = MaterialTheme.colorScheme.primary,
    trackColor: Color = MaterialTheme.colorScheme.surfaceVariant,
    outlineColor: Color = MaterialTheme.colorScheme.outline,
) {
    val transition = rememberInfiniteTransition(label = "wave")
    val phase by transition.animateFloat(
        initialValue = 0f,
        targetValue = (2 * PI).toFloat(),
        animationSpec = infiniteRepeatable(tween(2600, easing = LinearEasing)),
        label = "phase",
    )
    val level by animateFloatAsState(fillFraction.coerceIn(0f, 1f), tween(500), label = "level")

    Box(modifier = modifier, contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            val tank = Path().apply {
                addRoundRect(RoundRect(0f, 0f, w, h, CornerRadius(w * 0.12f)))
            }
            drawPath(tank, trackColor)
            clipPath(tank) {
                val top = h * (1f - level)
                val amplitude = if (level in 0.02f..0.98f) h * 0.02f else 0f
                val wave = Path().apply {
                    moveTo(0f, h)
                    lineTo(0f, top)
                    var x = 0f
                    while (x <= w) {
                        lineTo(x, top + amplitude * sin(phase + (x / w) * 3f * PI.toFloat()))
                        x += 4f
                    }
                    lineTo(w, h)
                    close()
                }
                drawPath(wave, fluidColor)
            }
            drawPath(tank, outlineColor, style = Stroke(width = 4f))
        }
        if (label != null) {
            Text(label, style = MaterialTheme.typography.displaySmall, color = MaterialTheme.colorScheme.onSurface)
        }
    }
}
