// Untimed v1.0.0 | 2026-10-06 | P-UNTIMED-ANDROID-001
package com.untimed.core.model

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/** [workRatio] work minutes earn [restRatio] rest minutes. workRatio 1–10, restRatio fixed at 1. */
@Entity(tableName = "ratio_presets", indices = [Index("label")])
data class RatioPreset(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val label: String,
    val workRatio: Int,
    val restRatio: Int = 1,
    val isDefault: Boolean = false,
)
