// Untimed v1.0.0 | 2026-10-06 | P-UNTIMED-ANDROID-001
package com.untimed.core.model

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

/** A work session, or the container for a block chain (see [kind]). */
@Entity(
    tableName = "sessions",
    foreignKeys = [
        ForeignKey(
            entity = RatioPreset::class,
            parentColumns = ["id"],
            childColumns = ["ratioPresetId"],
            onDelete = ForeignKey.SET_NULL,
        ),
        ForeignKey(
            entity = BucketTag::class,
            parentColumns = ["id"],
            childColumns = ["bucketTagId"],
            onDelete = ForeignKey.SET_NULL,
        ),
    ],
    indices = [Index("startTime")],
)
data class Session(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val startTime: Long,
    val endTime: Long? = null,
    val durationMs: Long = 0,
    val ratioPresetId: Long? = null,
    val bucketTagId: Long? = null,
    val surgeMultiplier: Float = 1f,
    val isActive: Boolean = true,
    /** [KIND_BANK] for time-bank sessions, [KIND_CHAIN] for the block-chain container. */
    val kind: String = KIND_BANK,
) {
    companion object {
        const val KIND_BANK = "BANK"
        const val KIND_CHAIN = "CHAIN"
    }
}
