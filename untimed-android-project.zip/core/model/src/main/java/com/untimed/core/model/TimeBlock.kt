// Untimed v1.0.0 | 2026-10-06 | P-UNTIMED-ANDROID-001
package com.untimed.core.model

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Ignore
import androidx.room.Index
import androidx.room.PrimaryKey
import kotlin.math.abs

@Entity(
    tableName = "time_blocks",
    foreignKeys = [
        ForeignKey(
            entity = Session::class,
            parentColumns = ["id"],
            childColumns = ["sessionId"],
            onDelete = ForeignKey.CASCADE,
        ),
    ],
    indices = [Index("sessionId"), Index("orderIndex")],
)
data class TimeBlock(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val sessionId: Long,
    val title: String,
    val scheduledStart: Long,
    val scheduledEnd: Long,
    val actualStart: Long? = null,
    val actualEnd: Long? = null,
    val orderIndex: Int,
    val autoAdvance: Boolean = true,
) {
    @get:Ignore
    val durationMs: Long get() = scheduledEnd - scheduledStart
}

/** Formats milliseconds as MM:SS or H:MM:SS. Negative values (overrun) get a leading minus. */
fun formatClock(ms: Long): String {
    val totalSeconds = abs(ms) / 1000
    val h = totalSeconds / 3600
    val m = (totalSeconds % 3600) / 60
    val s = totalSeconds % 60
    val body = if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%02d:%02d".format(m, s)
    return if (ms < 0) "-$body" else body
}
