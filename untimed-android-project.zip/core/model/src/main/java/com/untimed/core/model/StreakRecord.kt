// Untimed v1.0.0 | 2026-10-06 | P-UNTIMED-ANDROID-001
package com.untimed.core.model

import androidx.room.Entity
import androidx.room.PrimaryKey

/** One row per calendar day. [date] is YYYY-MM-DD in local time. The primary key is already indexed. */
@Entity(tableName = "streak_records")
data class StreakRecord(
    @PrimaryKey val date: String,
    val hasSession: Boolean,
    val sessionCount: Int,
)
