# Untimed

An Android time-banking timer. Work time earns rest time at a ratio you pick. Long runs trigger surge multipliers. Unused rest decays at midnight.

Pipeline ID: P-UNTIMED-ANDROID-001. Design Authority: design.md v1.1.

## How it works

| Concept | Rule |
|---|---|
| Ratio | Work minutes earn rest minutes at N:1. Presets seed at 5:1 (Reverse Pomodoro, A-14), 3:1, 10:1. Range 1–10. |
| Bucket weight | Each bucket multiplies earning by 0.5x–2.0x in 0.1 steps (A-11). |
| Surge | 1.5x after 30 continuous minutes, 2.0x after 60 (Q8). |
| Cash out | Converts the bank into a live countdown. Depletion plays the long chime. |
| Time Dump | Empties the bank. Never touches streak records (A-13). |
| Decay | At local midnight a user-set share (10–90%, default 50%) of the bank is removed. |
| Blocks | 1–20 blocks run back to back. Early completion starts the next block now. Overrun pushes later blocks forward (Q7). |
| Streak | A day counts when at least one bank session starts. |
| Restart safety | Bank, mode and elapsed time are saved every 10 seconds and on every change. A rest countdown keeps draining across a restart or reboot; a work run returns paused. |
| Decay catch-up | Decay applies once per missed midnight and records the last applied day, so late, skipped or repeated runs stay correct. |

## Modules

`:app` hosts navigation, Hilt modules and the boot receiver. `:core:model`, `:core:data`, `:core:engine`, `:core:service` and `:core:ui` hold domain, persistence, timing logic, foreground services and shared Compose. Four `:feature:*` modules hold the screens. Table B of design.md defines the dependency graph.

## Build

CI is the intended path. The workflow builds from a normal checkout, or from this project uploaded as a single `.zip` (it unzips the file, then builds). Push to `main` or run the workflow by hand; it uploads the artifact `untimed-debug-apk` and runs the unit tests as a non-blocking step.

Local: JDK 17 and the Android SDK (platform 35), then `./gradlew assembleDebug`.

## Pinned versions

Kotlin 1.9.24, AGP 8.5.2, Gradle 8.7, Compose BOM 2024.09.00 with compiler 1.5.14, Hilt 2.51.1, Room 2.6.1, DataStore 1.1.1, WorkManager 2.9.1, colorpicker-compose 1.1.0. Min SDK 24, target SDK 35, application ID `com.untimed.app`.

## Known limits

| Item | Status |
|---|---|
| Sound files | Generated placeholders (A-16, T-06). Replace the three files in `app/src/main/res/raw/` with real chimes under the same names, or rerun `python tools/generate_chimes.py`. |
| Compilation | All 46 Kotlin files pass a Kotlin 1.9.24 parse check. Full compilation needs the Android SDK and Google Maven, which the authoring environment lacked, so the first CI run is the first full compile. |
| Launcher icon | Vector approximation of the heraldic mark: crossed pens with flags, open book, stopwatch. |
| Exact alarms | Used as a wake-up for surge tiers, block ends and rest ends. Android 12 and 12L need the user to grant the exact-alarm permission; without it the alarm is inexact. |

Version 1.0.0, 2026-10-06.
